test = {
  'name': 'q1_1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> N == "parameter" or N == "statistic"
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> N_estimate == "parameter" or N_estimate == "statistic"
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
