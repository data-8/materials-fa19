test = {
  'name': 'q2_2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> type(true_statements)
          numpy.ndarray
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> min(true_statements) >= 1 and max(true_statements) <= 4
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
