test = {
  'name': 'q3_2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> type(new_observations)
          datascience.tables.Table
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> type(new_mean_based_estimate) in set([float, np.float32, np.float64])
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> type(new_bootstrap_estimates)
          numpy.ndarray
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> type(new_left_end) in set([float, np.float32, np.float64]) and type(new_right_end) in set([float, np.float32, np.float64])
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
