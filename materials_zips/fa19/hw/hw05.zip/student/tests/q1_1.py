test = {
  'name': 'q1_1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> compute_exercise_time(exercise.row(0))
          50.0
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> compute_exercise_time(exercise.row(20))
          130.0
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
