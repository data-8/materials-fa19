test = {
  'name': 'q3_8',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> smaller_sample_size < michelle_sample_size
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
