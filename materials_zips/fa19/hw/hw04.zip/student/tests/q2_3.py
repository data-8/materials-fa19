test = {
  'name': 'q2_3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # Hint: Make sure to use .item() instead of [] to access the element.;
          >>> import numpy;
          >>> type(biggest_range_dept) != numpy.str_
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> type(biggest_range_dept) == str
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
