test = {
  'name': 'q6_1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> fruits.sort(0)
          fruit name | count
          apple      | 4
          orange     | 3
          pineapple  | 3
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
