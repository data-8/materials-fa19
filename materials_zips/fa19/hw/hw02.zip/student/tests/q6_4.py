test = {
  'name': 'q6_4',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> sales.sort(0)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
