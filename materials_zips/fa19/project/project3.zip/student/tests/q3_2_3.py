test = {
  'name': 'q3_2_3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(0)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(1)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(2)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(3)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(4)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(5)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(6)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(7)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(8)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(9)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> def check(r):
          ...     t = test_20.row(r)
          ...     return classify(t, train_20, train_movies.column('Genre'), 11) == classify_feature_row(t);
          >>> check(10)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
