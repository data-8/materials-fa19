test = {
  'name': 'q3_3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> len(denmark_means) == repetitions
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> len(np.unique(denmark_means)) > 1
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
