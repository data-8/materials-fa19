test = {
  'name': 'q211',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # Hint: You can write the sine of 1.5*pi as:;
          >>> #   math.sin(1.5 * math.pi);
          >>> import math;
          >>> round(sine_of_pi_over_four, 8)
          0.70710678
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
