test = {
  'name': 'q12',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> say_please == 'More please'
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
